import pandas as pd
from pathlib import Path

DATA_DIR = Path("data")

# 1. Create mock_capstone_sales.csv
sales_rows = [
    # North (Months 1-9)
    ["M1", "North", "CardioMax", 1.80, 0.20, 2400, 2500, 15, 1200],
    ["M2", "North", "CardioMax", 2.10, 0.20, 2800, 2800, 15, 1250],
    ["M3", "north ", "CardioMax", 2.50, 0.22, 3250, 3100, 15, 1220], # Trailing space defect
    ["M4", "North", "CardioMax", 2.80, 0.22, 3640, 3500, 15, 1240],
    ["M5", "North", "CardioMax", 3.10, 0.22, 4030, 3900, 15, 1260],
    ["M6", "North", "CardioMax", 3.40, 0.25, 4250, 4200, 15, 1280],
    ["M7", "North", "CardioMax", 3.70, 0.25, "4,625", 4500, 15, 1250], # Text comma defect
    ["M8", "North", "CardioMax", 4.00, 0.25, 5000, 4800, 15, 1270],
    ["M9", "North", "CardioMax", 4.30, 0.25, 5375, 5100, 15, 1290],
    # South (Months 1-9 summary records)
    ["M1", "South", "CardioMax", 1.60, 0.20, 2133, 2200, 18, 1750],
    ["M2", "South", "CardioMax", 1.70, 0.20, 2266, 2300, 18, 1780],
    ["M3", "South", "CardioMax", 1.90, 0.20, 2533, 2500, 18, 1800],
    ["M4", "South", "CardioMax", 2.00, 0.20, 2666, 2600, 18, 1820],
    ["M5", "South", "CardioMax", 2.10, 0.20, 2800, 2750, 18, 1800],
    ["M6", "South", "CardioMax", 2.15, 0.20, 2866, 2850, 18, 1810],
    ["M7", "South", "CardioMax", 2.20, 0.20, 2933, 2900, 18, 1820],
    ["M8", "South", "CardioMax", 2.25, 0.20, 3000, 2950, 18, 1800],
    ["M9", "South", "CardioMax", 2.30, 0.20, 3069, 2950, 18, 1820],
    # East (Months 1-9 summary records)
    ["M1", "East", "CardioMax", 0.60, 0.18, 833, 1000, 10, 920],
    ["M2", "East", "CardioMax", 0.65, 0.18, 902, 1100, 10, 930],
    ["M3", "East", "CardioMax", 0.70, 0.18, 972, 1200, 10, 940],
    ["M4", "East", "CardioMax", 0.75, 0.18, 1041, 1300, 10, 950],
    ["M5", "East", "CardioMax", 0.80, 0.18, 1111, 1350, 10, 940],
    ["M6", "East", "CardioMax", 0.85, 0.18, 1180, 1400, 10, 950],
    ["M7", "East", "CardioMax", 0.90, 0.18, 1250, 1500, 10, 960],
    ["M8", "East", "CardioMax", 0.95, 0.18, 1319, 1550, 10, 950],
    ["M9", "East", "CardioMax", 1.00, 0.18, 1392, 1600, 10, 960],
    # West (Months 1-9 summary records - high GTN, low attainment)
    ["M1", "West", "CardioMax", 1.10, 0.30, 1192, 2100, 16, 1900],
    ["M2", "West", "CardioMax", 1.12, 0.30, 1213, 2150, 16, 1920],
    ["M3", "West", "CardioMax", 1.15, 0.32, 1245, 2200, 16, 1950],
    ["M4", "West", "CardioMax", 1.15, 0.35, 1245, 2250, 16, 1960],
    ["M5", "West", "CardioMax", 1.16, 0.35, 1256, 2250, 16, 1980],
    ["M6", "West", "CardioMax", 1.18, 0.36, 1278, 2250, 16, 1970],
    ["M7", "West", "CardioMax", 1.18, 0.38, 1278, 2260, 16, 1980],
    ["M8", "West", "CardioMax", 1.18, 0.40, 1278, 2270, 16, 1960],
    ["M9", "West", "CardioMax", 1.18, 0.40, 1281, 2270, 16, 1980],
]

df_sales = pd.DataFrame(sales_rows, columns=[
    "Month", "Region", "Product", "Invoiced_Gross_RsCr", 
    "GTN_Deduction_Pct", "Physical_Units_Packs", 
    "Target_TRx_Packs", "Sales_Reps", "Completed_Calls"
])
df_sales.to_csv(DATA_DIR / "mock_capstone_sales.csv", index=False)
print("Saved data/mock_capstone_sales.csv")

# 2. Create mock_capstone_survey.csv
survey_rows = [
    ["Metro Corporate Hospitals", 120, 114, 102, 70, 35, "Hospital Formulary Rejection", "Lack of Nurse Training"],
    ["Independent / Tier-2 Clinics", 180, 159, 120, 26, 7, "Patient Out-of-Pocket Cost", "Local Pharmacy Stockouts"]
]
df_survey = pd.DataFrame(survey_rows, columns=[
    "Practice_Setting", "Physician_Count", "Aided_Awareness_Count",
    "Trial_Willingness_Count", "Ever_Prescribed_Trial_Count",
    "Regular_Prescriber_Count", "Primary_Barrier", "Secondary_Barrier"
])
df_survey.to_csv(DATA_DIR / "mock_capstone_survey.csv", index=False)
print("Saved data/mock_capstone_survey.csv")

# 3. Create mock_capstone_access.csv
access_rows = [
    ["Corporate Private Insurers", 12000000, "Tier 2 (Co-Pay: Rs 600/Mo)", "Tier 2 (Co-Pay: Rs 600/Mo)", "Tier 3 (Co-Pay: Rs 2400/Mo)"],
    ["Government Schemes (CGHS/ESI)", 28000000, "Excluded (Pending Tender)", "Listed (National Tender)", "Listed (National Tender)"],
    ["Major Hospital Formularies", 80, "Listed in 32 of 80 (40%)", "Listed in 74 of 80 (92%)", "Listed in 65 of 80 (81%)"]
]
df_access = pd.DataFrame(access_rows, columns=[
    "Channel", "Universe_Size", "CardioMax_Status", "Competitor_Brand_A", "Competitor_Brand_B"
])
df_access.to_csv(DATA_DIR / "mock_capstone_access.csv", index=False)
print("Saved data/mock_capstone_access.csv")
